# Theme
for active theme:
```JAVASCRIPT
Themes.apply(name)

```
