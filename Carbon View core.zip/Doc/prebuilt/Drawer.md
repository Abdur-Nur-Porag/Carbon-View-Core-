# Drawer
Syntex
```JAVASCRIPT
Drawer({
Name:"",
Position:"",//left or right
BackdropEffect :(backdrop){
//js function or opration
},
Children:{
//obj based
}
});
```
### ***Parameters Identification***

| Parameters          | Info                                               |
| ------------------- | -------------------------------------------------- |
| Name                | Drawer name                                        |
| Position            | left or right                                      |
| BackdropCallback:() | If click outside of drawer this opration will work |
| Children            | Ex: create() or H1() this type                     |
|Blur        | Elevation label 0 to 1|
#### ***BackdropCallback:()***
***Example***
```JAVASCRIPT
Drawer({
Name:"",
Position:"",//top or bottom
BackdropEffect :(backdrop){
//here is example
console.log("You have click outside of drawer")

},
Children:{
//obj based
}
});
```

### ***Open Drawer***
```JAVASCRIPT
openDrawer(name)//with backpress
showDrawer(name)//without backpress
```
### ***Close Drawer***
```JAVASCRIPT
closeDrawer(name)//with backpress
hideDrawer(name)//without backpress

```

#### ***Installation***
```HTML
<script src="engine/preBuilt/4Ui/4ui.min.js"></script>
```
