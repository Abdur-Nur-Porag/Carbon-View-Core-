# Alignment 
```JAVASCRIPT
const name=Align({
  Align:left/right/center,
  Children:{obj}
})

```