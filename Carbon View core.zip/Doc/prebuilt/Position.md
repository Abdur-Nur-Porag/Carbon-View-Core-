# Position
**Position({})** is use to place a elements top,middle,bottom with proper alignment.
```JAVASCRIPT
const name=Position({
Align:left/right/center,
Position:top/bottom/middle,
Height:"",
Width:"",
Children:{obj}
})
```
**Remember** for position box **Height** and **Width** is need to execute proper position. 
