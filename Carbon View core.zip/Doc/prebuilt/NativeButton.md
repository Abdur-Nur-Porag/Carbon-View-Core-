# Native Button
Use Example
```JAVASCRIPT
const name=NativeButton({
  Name:"",
  Width:"",
  Height:"",
  Style:"",
  Text="",
  Elevation:0 to 10,
}).app(id)
.support all build Api


```