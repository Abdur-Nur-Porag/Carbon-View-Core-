# AppBar
```JAVASCRIPT
const AppBar=AppBar({
 Style:{},
 Elevation:1 to 5,
 Left:{},
 LeftStyle:{},
 Center:{},
 CenterStyle:{},
 Right:{},
 RightStyle:{},
 
})


```