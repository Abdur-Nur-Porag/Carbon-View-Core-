# ActionS
Syntex
```JAVASCRIPT
ActionSheet({
Name:"",
Position:"",//top or bottom
BackdropEffect :(backdrop){
//js function or opration
},
Children:{
//obj based
}
});
```
### ***Parameters Identification***

| Parameters          | Info                                                    |
| ------------------- | ------------------------------------------------------- |
| Name                | ActionSheet name                                        |
| Position            | bottom or top                                           |
| BackdropCallback:() | If click outside of actionsheet this opration will work |
| Children            | Ex: create() or H1() this type                          |
|Blur        | Elevation label 0 to 1|
#### ***BackdropCallback:()***
***Example***
```JAVASCRIPT
ActionSheet({
Name:"",
Position:"",//top or bottom
BackdropEffect :(backdrop){
//here is example
console.log("You have click outside of actionsheet")

},
Children:{
//obj based
}
});
```

### ***Open ActionSheet***
```JAVASCRIPT
openActionSheet(name)//work with backpress
showActionSheet(name)//not work with backpress
```
### ***Close ActionSheet***
```JAVASCRIPT
closeActionSheet(name)//backpress work
hideActionSheet(name)//backpress not work

```

#### ***Installation***
```HTML
<script src="engine/preBuilt/4Ui/4ui.min.js"></script>
```
