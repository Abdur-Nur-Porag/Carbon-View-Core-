Syntex
```JAVASCRIPT
Dialog({
Name:"",
Blur:numaric value// int value 0 to 10
BackdropEffect :(backdrop){
//js function or opration
},
Children:{
//obj based
}
});
```
### ***Parameters Identification***

| Parameters          | Info                                               |
| ------------------- | -------------------------------------------------- |
| Name                | Dialog name                                        |
|                     |                                                    |
| BackdropCallback:() | If click outside of dialog this opration will work |
| Children            | Ex: create() or H1() this type                     |
| Blur                | Elevation label 0 to 10                            |
#### ***BackdropCallback:()***
***Example***
```JAVASCRIPT
Dialog({
Name:"",
Blur:numaric value// int value 0 to 10
BackdropEffect :(backdrop){
//js function or opration
console.log("You have click outside of dialog)
},
Children:{
//obj based
}
});
```

### ***Open Drawer***
```JAVASCRIPT
openDialog(name)//with backpress
showDialog(name)//without backpress
```
### ***Close Drawer***
```JAVASCRIPT
closeDialog(name)//with backpress
hideDialog(name)//without backpress
```

#### ***Installation***
```HTML
<script src="engine/preBuilt/4Ui/4ui.min.js"></script>
```
