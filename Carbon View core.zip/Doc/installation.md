# Installation

### 1. Use the following `index.html` as your main app file:
### Release Version:
`
 current version: cv 1.0Heavy (Main)
 current lite version: cv 1.0Lite
 
`
### 

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
    content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>CarbonView Framework</title>

  <!-- UIKit CSS -->
  <link rel="stylesheet" href="uikit/css/beer.css">
  <link rel="stylesheet" href="engine/preBuilt/4Ui/ActionSheet.css">
  <link rel="stylesheet" href="engine/preBuilt/4Ui/Dialog.css">
  <link rel="stylesheet" href="engine/preBuilt/4Ui/Drawer.css">
  <link rel="stylesheet" href="engine/preBuilt/GridView/GridView.css">
  <link rel="stylesheet" href="engine/preBuilt/ScrollView/ScrollView.css">
  <link rel="stylesheet" href="engine/preBuilt/NativeButton/NativeButton.css">
  <link rel="stylesheet" href="engine/preBuilt/Ripple/Ripple.css">
<link rel="stylesheet" href="engine/preBuilt/Dialog/Dialog.css">
<link rel="stylesheet" href="engine/preBuilt/MaterialInput/MaterialInput.css">
  <!-- Protection Styles -->
  <style>
    html, body {
      margin: 0;
      padding: 0;
      user-select: none;
      -webkit-user-select: none;
      -ms-user-select: none;
      touch-action: manipulation;
    }
    * {
      -webkit-tap-highlight-color: transparent;
    }
  #app{
    height:100vh;
  }
  </style>
</head>

<body>
  <div id="app"></div>

  <!-- Core -->
  <script src="engine/core/carbon.buildApi.js"></script>
  <script src="engine/core/core.function.js"></script>
  <script src="engine/core/loadExternal.js"></script>
  <!--
  <script type="module" src="uikit/js/beer.min.js"></script>
  -->

  <!-- Components -->
<script src="engine/preBuilt/4Ui/4ui.min.js"></script>
  
  <!--
  Remember:
  4ui.min.js 
  is file which contain 4 prebuilt component:
  - PageView
  - ActionSheet
  - Drawer
  - Dialog
  so, 4ui.min.js is use instead of useing 4 seperate js file. 
  Avoid Files:
  - ActionSheet.js
  - Drawer.js
  - Dialog.js
  - PageView.js
  
  
  -->

  
  <script src="engine/preBuilt/Alignment/Align.js"></script>
  <script src="engine/preBuilt/ColumnView/ColumnView.js"></script>

  <script src="engine/preBuilt/GridView/GridView.js"></script>
  <script src="engine/preBuilt/NativeToast/NativeToast.js"></script>
  
  <script src="engine/preBuilt/ScrollView/ScrollView.js"></script>
  <script src="engine/preBuilt/SlideView/SlideView.js"></script>
  <script src="engine/preBuilt/AppBar/AppBar.js"></script>
  <script src="engine/preBuilt/NativeButton/NativeButton.js"></script>
  <script src="engine/preBuilt/Ripple/Ripple.js"></script>
  <script src="engine/preBuilt/Position/Position.js"></script>
  <script src="engine/preBuilt/MaterialInput/MaterialInput.js"></script>
  <!-- Themes -->
  <script src="engine/themes/themes.js"></script>
  <script src="engine/themes/themes.config.js"></script>
  <script type="module" src="uikit/js/material-dynamic-colors.min.js"></script>

  <!-- Activate Theme -->
  <script>
    Themes.apply("light");
  </script>

  <!-- Protection Scripts -->
  
  <script>
    // Disable context menu
    window.addEventListener("contextmenu", e => e.preventDefault());

    // Disable copy, cut, paste
    ["copy", "cut", "paste"].forEach(evt =>
      document.addEventListener(evt, e => e.preventDefault())
    );

    // Disable selection
    document.addEventListener("selectstart", e => e.preventDefault());

    // Disable gesture zoom
    document.addEventListener("gesturestart", e => e.preventDefault());

    // Disable multi-touch zoom
    document.addEventListener("touchstart", e => {
      if (e.touches.length > 1) e.preventDefault();
    }, { passive: false });
  </script>


  <!-- Load Custom Views -->
  <!--view/main-->
  
  <script src="view/main/MainView/MainView.js"></script>

  <!--view/example-->
  
  

  
  <!--App.js is entry point-->
<script src="view/app.js" defer></script>
  

</body>
</html>
```
### **Tutorial**
We suggest for everyone to see documention first then start code.
Here **core** show basic working process of dom manipulation and others. **Learn Core first**.

**Prebuilt** is contain various prebuilt ui.This help to write your code more fastly with powerfull ui.
** All Prebuilt ** are based on **core** so we suggest learn **core** first then proceed to others.

**Themes** help to maintain colors, shadow,elevation etc.

- [core](/Doc/core.md)
- [preBuilt](/Doc/preBuilt.md)
- [themes](/Doc/themes.md)


