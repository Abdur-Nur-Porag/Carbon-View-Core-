const ActionSheets = {};

function ActionSheet({
  Name,
  Position = "bottom",
  BackdropEffect = ({ backdrop }) => backdrop.addStyle({ backdropFilter: "blur(6px)" }),
  Style = {},
  Children = {}
}) {
  if (document.getElementById(Name)) return;

  // Create backdrop
  const backdrop = create("div")
    .addClass("action-backdrop")
    .add(document.body)
    .onClick(() => {
      // Update Router.json and hide the sheet
      setTimeout(() => {
        closeActionSheet(Name); // updates Router.json
        hideActionSheet(Name);  // hide visually
      }, 0);
    });

  // Apply user-defined backdrop effect
  BackdropEffect({ backdrop });

  // Create wrapper
  const wrapper = create("div")
    .id(Name)
    .addClass(["action-sheet", Position])
    .addStyle(Style)
    .add(document.body);

  // Create content
  const content = create("div")
    .addClass("sheet-content")
    .add(wrapper);

  for (const key in Children) {
    const child = Children[key];
    if (child?.el instanceof HTMLElement) {
      content.el.appendChild(child.el);
    }
  }

  ActionSheets[Name] = {
    wrapper,
    backdrop,
    Position
  };
}

function showActionSheet(name) {
  const sheet = ActionSheets[name];
  if (!sheet) return;

  sheet.backdrop.addClass("showing");
  sheet.wrapper.addClass("showing");
  document.body.style.overflow = "hidden";
}

function hideActionSheet(name) {
  const sheet = ActionSheets[name];
  if (!sheet) return;

  sheet.wrapper.removeClass("showing");
  sheet.backdrop.removeClass("showing");

  setTimeout(() => {
    document.body.style.overflow = "";
  }, 350);
}
