const Drawers = {};

function Drawer({
  Name,
  Position = "left",
  Style = {},
  Children = {},
  BackdropEffect = ({ backdrop }) => backdrop.addStyle({ backgroundColor: "rgba(0,0,0,0.3)" })
}) {
  if (!Name) throw new Error("❌ Drawer must have a 'Name'.");
  if (Drawers[Name]) return;

  // Create drawer element
  const drawer = create("div")
    .addClass(["drawer", Position])
    .addStyle(Style)
    .addObj(Children)
    .add(document.body);

  // Create backdrop
  const backdrop = create("div")
    .addClass("drawer-backdrop")
    .add(document.body)
    .onClick(() => {
      // Update Router.json and hide drawer
      setTimeout(() => {
        closeDrawer(Name); // updates Router.json
        hideDrawer(Name);  // hide visually
      }, 0);
    });

  // Apply user-defined backdrop effect
  BackdropEffect({ backdrop });

  Drawers[Name] = {
    drawer,
    backdrop,
    Position
  };
}

function showDrawer(name) {
  const ref = Drawers[name];
  if (!ref) return;

  ref.drawer.addClass("showing");
  ref.backdrop.addClass("showing");
  document.body.style.overflow = "hidden";
}

function hideDrawer(name) {
  const ref = Drawers[name];
  if (!ref) return;

  ref.drawer.removeClass("showing");
  ref.backdrop.removeClass("showing");

  setTimeout(() => {
    document.body.style.overflow = "";
  }, 350);
}
