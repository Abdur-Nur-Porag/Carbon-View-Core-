/*
.ripple({
  status:true/false,
  background:"color",
  duration:time
})

this add inside carbon.buildApi.js
*/