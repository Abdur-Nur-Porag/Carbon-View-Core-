/*const loading=create("progress").class(["circle"])

const loadingBox=Div()
.children({
  loading:loading,
})
.style({
  marginBottom:"10px",
  marginLeft:"25%"
})
const loadingPage=Div()
.children({
  bottomBox:Position({
    Align:"center",
    Position:"bottom",
    Height:"100vh",
    Width:"100vw",
    Children:{
      loadingBox:loadingBox,
      text:create("p").text("Please Wait...")
    }
  })
  
})
.add("#app")

setTimeout(()=>{
  loadingPage.style({
    display:"none"
  })//
  
  //Enable AllView
  PageView({
    Name:"MainView",
    InitialPage:true,
    Children:[_MainView()]
  })
  
  
  
  
},3500)
*/
PageView({
    Name:"AllServerView",
    InitialPage:true,
    Children:[_ServerView()]
  })
  

