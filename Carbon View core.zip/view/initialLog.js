//check exist of file 
const VpnLogText={
  Name:"Cloudflare",
  Address:"10.10.10.10",
  Dns:"8.8.8.8",
  Status:"inactive"//active / inactive
}
const VpnLogFile=JSON.stringify(VpnLogText)

InternalFileBridge.WriteFile("vpn.log",VpnLogFile)
//check exists of vpnHistory.log && allServer.log
const VpnHistory="vpnHistory.log"
const AllServer="allServer.log"

const VpnHistoryText=[]
const AllServerText=[]

const VpnHistoryFile=JSON.stringify(VpnHistoryText)
const AllServerFile=JSON.stringify(AllServerText)

InternalFileBridge.WriteFile(VpnHistory, VpnHistoryFile)
InternalFileBridge.WriteFile(AllServer, AllServerFile)
console.log("All Ok")

if(InternalFileBridge.CheckExists(VpnHistory)==="true"&&InternalFileBridge.CheckExists(AllServer)==="true"){
  console.log("File is exist,No need to create ")
}
else{
  console.log("First time attempt.")
  //write file
  InternalFileBridge.WriteFile(VpnHistory, VpnHistoryFile)
InternalFileBridge.WriteFile(AllServer, AllServerFile)
}