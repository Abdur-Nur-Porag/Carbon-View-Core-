const _AppBar=AppBar({
  Left:{
    /* left drawer button*/
    Bt:Button().class(["transparent","circle"]).html("<i>menu</i>").style({
      marginLeft:"-10%"
    }).id("drawerButton")
  }
})
.event("click",()=>{
  // 
  _MainViewDrawer()
})
_AppBar.class(["transparent"])

const _Body=Div()
.style({
  marginTop:"0%",
  height:"100vh",
  width:"100vw"
})

const _Icon=create("img")
.attrs({
  src:Path("guard-lock-padlock-svgrepo-com.svg"),
  alt:"app icon"
})
_Icon.class(["extra"])

const _VpnConfig=NativeButton({
  Name:"",
  Text:""
})
.ripple({
  status:true
})
.children({
  Img:create("img").attrs({
    src:Path("guard-key-lock-2-svgrepo-com.svg")
  }).class(["small"]),
  Text:Span().text("Vpn Config")
})
.event("click",()=>{
  _VpnConfig()
})
const _VpnHistory=NativeButton({
  Text:""
})
.ripple({
  status: true
})
.children({
  Img: create("img").attrs({
    src: Path("laptop-password-privacy-svgrepo-com.svg")
  }).class(["small"]),
  Text: Span().text("History")
})
.event("click",()=>{
  _VpnHistory()
})

const _GridView=GridView({
  id:"GridView_1",
  width:"100px",
  height:"60px",
  items:[_VpnConfig,_VpnHistory]
})
.style({
  marginRight:"2%"
})
const _IconBox=Align({
  Align:"center",
  Children:{
    Icon:_Icon,
  }
})
const _GridViewBox=Align({
  Align:"center",
  Children:{
    GridView:_GridView
  }
})
.style({border:""})

const _Title=H6().text("Enable Vpn").id("VpnStatus")
const _SubTitle=Div().text("Server Address:").id("ServerStatus")

const _Input=Input().attrs({type:"checkbox"})


function _SwitchBox(){
  const _box=Div().class(["field","middle-align"])
  _box.children({
    Nav:Nav().children({
      Div:Div().class(["max"]).children({
        Title:_Title,
        Sub:_SubTitle,
      }),
      Label:Label().class(["switch"]).children({
        Input:_Input,
        Span:Span()
      })
    })
  })
  _box.style({width:"100vw"})
  
  
  
  
  
  return _box;
}

const _VpnSwitchBox=Align({
  Align:"center",
  Children:{
    SwitchBox:_SwitchBox()
  }
})
.style({
  marginTop:"30px"
})

const _ChangeServerBt=NativeButton({
  Text:"",
  Height:"50px"
})
.ripple({
  status:true
})
.class(["responsive"])
.style({
  width:"100%"
})
.event("click",()=>{
  
})
.children({
  Img:create("img").attrs({
    src:Path("door-key-protection-svgrepo-com.svg")
  }).class(["small"]),
  Text:Span().text("Change Server")
})
.event("click",()=>{
  _ChangeServer()
})
const _ChangeServerBox=Align({
  Align:"center",
  Children:{
    Bt:_ChangeServerBt
  }
})
.style({
  marginTop:"10px"
})



const _Container=Div().children({
  Icon:_IconBox,
  VpnSwitchBox:_VpnSwitchBox,
  GridView:_GridViewBox,
  ChangeServerBox:_ChangeServerBox,
})
.style({
  marginBottom:"",
  width:"90vw",
  border:""
})

const _PositionBox=Position({
  Align:"center",
  Position:"middle",
  Height:"100%",
  Width:"100%",
  Children:{
    Container:_Container,
  }
})
_PositionBox.class(["transparent"])
_Body.addObj({
  PositionBox:_PositionBox
})



function _MainView(){
  return Div().children({
    AppBar:_AppBar,
    Body:_Body
  })
}


/* Making Global Function */
GlobalManager.register({_Title,_SubTitle,_Input})

console.log(GlobalManager.listVar)