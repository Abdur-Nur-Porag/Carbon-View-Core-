const readVpnLog=InternalFileBridge.ReadFile("vpn.log")
const readData=JSON.parse(readVpnLog)
console.log(`MainviewFunction.js readData ${readVpnLog}`)

const address=readData.Address;
const dns=readData.Dns;
const name=readData.Name;
const status=readData.Status;
const _OldTitle=GlobalManager.useVar("_Title")
const _OldSub=GlobalManager.useVar("_SubTitle")
const _OldSwitch=GlobalManager.useVar("_Input")
if(readData.Status==="active"){
  //enable switch
  _OldInput.check()
  // Update title and sub
  _OldTitle.text("Connected")
  const subTitle="Address: "+address;
  _OldSub.text(subTitle)
  
  
  //enable vpn features
}
else if (readData.Status==="inactive") {
  // no change
}

/** switch button click opration **/

function statusConvert(text){
  if(text=="active"){return true}
  else{return false}
}
const switchButton=_OldSwitch;
switchButton.toggleEvent({
  initial:statusConvert(status),
  WhenTrue:()=>{
    //already active
    //unckecking
    switchButton.uncheck()
       _OldTitle.text("DisConnected")
      const subTitle="Address: Unavailable ";
      _OldSub.text(subTitle)
  
    //click--->inactive
    
    
     const oldVpnLog=readData;
     oldVpnLog["Status"]="inactive"
     const newVpnLog=JSON.stringify(oldVpnLog)
     InternalFileBridge.WriteFile("vpn.log",newVpnLog)
    
    console.log(`when true:${newVpnLog}`)
  
    
  },
  WhenFalse:()=>{
    //already inactive
    //checking
    switchButton.check()
    //changeing text
      _OldTitle.text("Connected")
    const subTitle="Address: "+address;
    _OldSub.text(subTitle)
  
    
    //click--->active
    const oldVpnLog = readData;
    oldVpnLog["Status"] = "active"
    const newVpnLog = JSON.stringify(oldVpnLog)
InternalFileBridge.WriteFile("vpn.log", newVpnLog)
    
    console.log(`when true:${newVpnLog}`)
    //check
    
  }
})
