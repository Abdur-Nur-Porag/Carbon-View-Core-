const Server=[
  {
    Name:"Google Clean Family",
    Address:"10.10.10.10",
    Dns:"8.8.8.8",
    Info:"This is google clean family server",
    Id:"1234567",
    Icon:"1.png",
  },
  {
  Name: "Carbon XX",
  Address: "20.20.20.20",
  Dns: "3.3.3.3",
  Info: "This is Carbon clean family server",
  Id: "1234567",
  Icon:"2.png",
},
{
  Name: "VB Family",
  Address: "30.30.30.30",
  Dns: "7.7.7.7",
  Info: "This is google clean family server",
  Id: "1234567",
  Icon:"3.png",
},
{
  Name: "Miliky Family",
  Address: "40.40.40.40",
  Dns: "9.9.9.9",
  Info: "This is google clean family server",
  Id: "1234567",
  Icon:"4.png",
}
]


const _SVAppBar=AppBar({
  Left:{
    Icon:Button().class(["transparent","circle"]).html("<i>arrow_back</i>").style({
      marginLeft:"-30%"
    })
  }
})

const VpnLog={
  Name:"Cloudflare"
}

const ListBox=Ul().class(["list","border"])
/*
<ul class>
  <li>
    <icon>
    <div class="max">
      <h6 class="small"></h6>
      <span></span>
    </div>
    <icon>
  </li>

</ul>
*/

Server.forEach(everyItem=>{
  //Name,Address,Dns,Info,Id,Icon
  const Name=everyItem.Name;
  const Address=everyItem.Address;
  const Dns=everyItem.Dns;
  const Info=everyItem.Info;
  const Icon=everyItem.Icon;
  const listItem=Li()
  
  /* <pre icon>*/
  const preIcon=CTButton().text(Icon)
  /*StartMax*/
  /*title*/
  const title=H6().class(["small"]).text(Name)
  /*subtitle*/
  const subtitle=Span().text(Address)
  const max=Div().class(["max"])
  max.addObj({title,subtitle})
  
  /*Endmax*/
  
  /*post icon*/
  const afterIcon=CTButton().html("<i>arrow_forward</i>")
  
  listItem.addObj({preIcon,max,afterIcon})
  ListBox.addObj({listItem})
  
})

//console.log(ListBox)
const _SVBody=Div().children({
  ServerList:ListBox
})
.style({
  marginTop:"20%"
})
function _ServerView(){
  return Div().children({
    AppBar:_SVAppBar,
    Body:_SVBody
  })
}